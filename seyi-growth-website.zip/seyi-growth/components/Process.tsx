'use client';

import { motion } from 'framer-motion';

const Process = () => {
  const steps = [
    {
      number: '01',
      title: 'Discovery Call',
      description:
        'We start with understanding your business, goals, current challenges, and what success looks like for you.',
    },
    {
      number: '02',
      title: 'Strategy & Audit',
      description:
        'I audit your store, competition, and market, then provide a clear roadmap with priorities and timelines.',
    },
    {
      number: '03',
      title: 'Build & Implement',
      description:
        'Execution happens with regular updates. Whether it\'s design, setup, or marketing—you\'re always in the loop.',
    },
    {
      number: '04',
      title: 'Optimize & Scale',
      description:
        'We review data weekly, cut what isn\'t working, and scale what is. Growth is a loop, not a launch.',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="process" className="py-20 bg-white">
      <div className="container-max">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h2 className="section-title">How It Works</h2>
          <p className="section-subtitle">
            A clear, transparent process from strategy to results.
          </p>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {steps.map((step, index) => (
            <motion.div key={index} variants={itemVariants} className="relative">
              {/* Connection Line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-full w-8 h-0.5 bg-gradient-to-r from-blue-600 to-blue-200" />
              )}

              <div className="bg-gradient-to-br from-blue-50 to-white border border-blue-100 rounded-xl p-6 h-full">
                <div className="text-4xl font-bold text-blue-600 mb-4">
                  {step.number}
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-3">
                  {step.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Process;
