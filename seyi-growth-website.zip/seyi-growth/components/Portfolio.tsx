'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { TrendingUp } from 'react-icons/fa';

const Portfolio = () => {
  const caseStudies = [
    {
      id: 1,
      title: 'LuxeWare - Fashion E-commerce',
      category: 'Shopify Optimization',
      description:
        'Redesigned product pages and checkout flow for a high-end fashion brand.',
      results: [
        { metric: '+68%', label: 'Conversion Rate' },
        { metric: '+$2.4K', label: 'Avg Order Value' },
      ],
      image: '👗',
    },
    {
      id: 2,
      title: 'EcoHome - Home & Garden',
      category: 'Shopify Setup & Design',
      description:
        'Built and launched complete Shopify store with branding, product listings, and marketing setup.',
      results: [
        { metric: '$45K', label: 'Revenue (First 3 Months)' },
        { metric: '2.1%', label: 'Conversion Rate' },
      ],
      image: '🌱',
    },
    {
      id: 3,
      title: 'VitaBoost - Health Supplements',
      category: 'Digital Marketing & SEO',
      description:
        'Combined SEO strategy with social media management and email marketing.',
      results: [
        { metric: '+156%', label: 'Organic Traffic' },
        { metric: '+$78K', label: 'Additional Revenue' },
      ],
      image: '💊',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="portfolio" className="py-20 bg-gray-50">
      <div className="container-max">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h2 className="section-title">Selected Work</h2>
          <p className="section-subtitle">
            Real projects, real results. Here are some of the stores I've
            optimized and launched.
          </p>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-1 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {caseStudies.map((study) => (
            <motion.div
              key={study.id}
              variants={itemVariants}
              className="bg-white rounded-xl overflow-hidden hover:shadow-xl transition-shadow duration-300"
            >
              <div className="h-48 bg-gradient-to-br from-blue-100 to-blue-50 flex items-center justify-center text-6xl">
                {study.image}
              </div>

              <div className="p-6">
                <p className="text-sm font-semibold text-blue-600 mb-2">
                  {study.category}
                </p>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {study.title}
                </h3>
                <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                  {study.description}
                </p>

                <div className="space-y-3 border-t border-gray-100 pt-6">
                  {study.results.map((result, idx) => (
                    <div key={idx} className="flex items-center justify-between">
                      <span className="text-gray-600 text-sm">{result.label}</span>
                      <span className="font-bold text-green-600 flex items-center gap-1">
                        <TrendingUp size={14} />
                        {result.metric}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-12 text-center"
        >
          <Link href="#contact" className="btn-primary">
            Start Your Project
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default Portfolio;
