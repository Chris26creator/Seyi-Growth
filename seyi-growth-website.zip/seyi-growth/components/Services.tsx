'use client';

import { motion } from 'framer-motion';
import { ShoppingCart, Globe, Palette, Search, TrendingUp, Share2 } from 'react-icons/fa';

const Services = () => {
  const services = [
    {
      id: 1,
      title: 'Shopify Setup & Design',
      description:
        'Launch your store with a high-converting design. Custom theme setup, product pages, and checkout optimization.',
      icon: ShoppingCart,
      color: 'from-blue-400 to-blue-600',
    },
    {
      id: 2,
      title: 'Website Design',
      description:
        'Professional websites that showcase your brand and convert visitors into customers.',
      icon: Globe,
      color: 'from-purple-400 to-purple-600',
    },
    {
      id: 3,
      title: 'Branding Strategy',
      description:
        'Build a premium brand identity with logo design, color systems, and brand guidelines.',
      icon: Palette,
      color: 'from-pink-400 to-pink-600',
    },
    {
      id: 4,
      title: 'SEO Optimization',
      description:
        'Rank higher on Google with technical SEO, keyword strategy, and content optimization.',
      icon: Search,
      color: 'from-green-400 to-green-600',
    },
    {
      id: 5,
      title: 'Digital Marketing',
      description:
        'Strategic campaigns across Google Ads, email marketing, and conversion optimization.',
      icon: TrendingUp,
      color: 'from-yellow-400 to-yellow-600',
    },
    {
      id: 6,
      title: 'Social Media Management',
      description:
        'Consistent, strategic content that builds authority and drives traffic to your store.',
      icon: Share2,
      color: 'from-orange-400 to-orange-600',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section id="services" className="py-20 bg-white">
      <div className="container-max">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h2 className="section-title">My Services</h2>
          <p className="section-subtitle">
            Everything you need to build and scale a profitable online business.
          </p>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {services.map((service) => {
            const IconComponent = service.icon;
            return (
              <motion.div
                key={service.id}
                variants={itemVariants}
                className="p-8 rounded-xl border border-gray-100 hover:border-blue-200 hover:shadow-lg transition-all duration-300"
              >
                <div
                  className={`w-12 h-12 rounded-lg bg-gradient-to-r ${service.color} flex items-center justify-center text-white mb-4`}
                >
                  <IconComponent size={24} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {service.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
