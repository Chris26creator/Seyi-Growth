'use client';

import { motion } from 'framer-motion';
import { Star } from 'react-icons/fa';

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      quote:
        "Seyi rebuilt our Shopify store and our conversion rate almost doubled in the first quarter. What stood out was how calmly the whole thing was run.",
      author: 'Adaeze O.',
      role: 'Founder, Luxury Fashion Store',
      rating: 5,
    },
    {
      id: 2,
      quote:
        "We finally have a content system instead of a scramble. Our Instagram went from an afterthought to our second-biggest revenue channel.",
      author: 'Tolu A.',
      role: 'Marketing Lead, Home & Living Brand',
      rating: 5,
    },
    {
      id: 3,
      quote:
        "The strategy work paid for itself in a month. He cut the channels that weren't working and told us exactly where to focus.",
      author: 'Michael K.',
      role: 'CEO, Tech E-commerce',
      rating: 5,
    },
    {
      id: 4,
      quote:
        "My brand finally looks like the prices I charge. Bookings and sales tripled and the customers coming in are a much better fit.",
      author: 'Grace E.',
      role: 'Founder, Premium Beauty Brand',
      rating: 5,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container-max">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h2 className="section-title">What Clients Say</h2>
          <p className="section-subtitle">
            Real feedback from businesses I've helped grow.
          </p>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-2 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {testimonials.map((testimonial) => (
            <motion.div
              key={testimonial.id}
              variants={itemVariants}
              className="bg-white rounded-xl p-8 shadow-sm hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className="text-yellow-400 fill-current"
                  />
                ))}
              </div>

              <p className="text-gray-700 text-lg leading-relaxed mb-6 italic">
                "{testimonial.quote}"
              </p>

              <div className="border-t border-gray-100 pt-4">
                <p className="font-bold text-gray-900">{testimonial.author}</p>
                <p className="text-sm text-gray-600">{testimonial.role}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;
