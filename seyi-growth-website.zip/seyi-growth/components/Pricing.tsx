'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { Check } from 'react-icons/fa';

const Pricing = () => {
  const plans = [
    {
      name: 'Starter',
      price: '$450',
      period: 'one-time',
      description: 'Perfect for getting set up properly',
      features: [
        'Brand & store audit',
        'Shopify store setup',
        'Product page templates',
        '30-day action plan',
        'One strategy call',
      ],
      highlighted: false,
    },
    {
      name: 'Growth',
      price: '$1,200',
      period: 'per month',
      description: 'For brands ready to scale consistently',
      features: [
        'Everything in Starter',
        'Full store optimization',
        'Monthly content production',
        'Social media strategy',
        'Email marketing setup',
        'Bi-weekly calls',
        'Monthly reporting',
      ],
      highlighted: true,
    },
    {
      name: 'Scale',
      price: 'Custom',
      period: 'retainer',
      description: 'For established brands with real volume',
      features: [
        'Everything in Growth',
        'Full-funnel growth strategy',
        'Paid & organic coordination',
        'Dedicated account manager',
        'Team training',
        'Weekly strategy calls',
        'Custom integrations',
      ],
      highlighted: false,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="container-max">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2 className="section-title">Simple, Transparent Pricing</h2>
          <p className="section-subtitle">
            Fixed quotes, no surprises. All packages customizable based on your
            needs.
          </p>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className={`rounded-2xl p-8 transition-all duration-300 ${
                plan.highlighted
                  ? 'bg-gradient-to-br from-blue-600 to-blue-700 text-white shadow-xl scale-105'
                  : 'bg-gray-50 border border-gray-200 text-gray-900'
              }`}
            >
              <h3
                className={`text-2xl font-bold mb-2 ${
                  plan.highlighted ? 'text-white' : 'text-gray-900'
                }`}
              >
                {plan.name}
              </h3>

              <div className="mb-2">
                <span className="text-4xl font-bold">{plan.price}</span>
                <span className={`ml-2 ${plan.highlighted ? 'text-blue-100' : 'text-gray-600'}`}>
                  {plan.period}
                </span>
              </div>

              <p
                className={`text-sm mb-8 ${
                  plan.highlighted ? 'text-blue-100' : 'text-gray-600'
                }`}
              >
                {plan.description}
              </p>

              <Link
                href="#contact"
                className={`block text-center py-3 px-4 rounded-lg font-semibold mb-8 transition-colors ${
                  plan.highlighted
                    ? 'bg-white text-blue-600 hover:bg-blue-50'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                Get Started
              </Link>

              <ul className="space-y-4">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <Check
                      size={20}
                      className={
                        plan.highlighted
                          ? 'text-blue-200 flex-shrink-0'
                          : 'text-blue-600 flex-shrink-0'
                      }
                    />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-12 text-center"
        >
          <p className="text-gray-600 mb-4">
            All quotes are fixed and written down. No surprise line items.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default Pricing;
