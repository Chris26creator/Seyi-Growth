'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight } from 'react-icons/fa';

const Hero = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8 },
    },
  };

  return (
    <section id="home" className="pt-20 pb-32 bg-gradient-to-b from-blue-50 to-white">
      <div className="container-max">
        <motion.div
          className="grid md:grid-cols-2 gap-12 items-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Left Column - Content */}
          <div>
            <motion.div variants={itemVariants}>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
                Turn Your Store Into a{' '}
                <span className="gradient-text">Sales Machine</span>
              </h1>
            </motion.div>

            <motion.p
              variants={itemVariants}
              className="text-lg text-gray-600 mb-8 leading-relaxed"
            >
              I help e-commerce brands and small businesses increase visibility,
              engagement, and sales through Shopify optimization, website design,
              strategic branding, and results-driven digital marketing.
            </motion.p>

            <motion.div variants={itemVariants} className="flex gap-4 flex-wrap">
              <Link href="#contact" className="btn-primary flex items-center gap-2">
                Book a Consultation <ArrowRight size={16} />
              </Link>
              <Link href="#work" className="btn-secondary">
                View My Work
              </Link>
            </motion.div>

            <motion.div
              variants={itemVariants}
              className="flex gap-8 mt-12 flex-wrap"
            >
              <div>
                <p className="text-3xl font-bold text-gray-900">50+</p>
                <p className="text-gray-600">Stores Optimized</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-gray-900">$2M+</p>
                <p className="text-gray-600">Revenue Generated</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-gray-900">3x</p>
                <p className="text-gray-600">Avg. Sales Increase</p>
              </div>
            </motion.div>
          </div>

          {/* Right Column - Visual */}
          <motion.div
            variants={itemVariants}
            className="hidden md:flex justify-center items-center"
          >
            <div className="relative w-full h-96 bg-gradient-to-br from-blue-100 to-blue-50 rounded-2xl flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl mb-4">🛍️</div>
                <p className="text-gray-600 font-semibold">
                  Your E-commerce Success Story
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
