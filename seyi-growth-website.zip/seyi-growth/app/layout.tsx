import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Seyi Growth | Shopify & E-commerce Growth Specialist',
  description:
    'I help businesses increase sales through Shopify store design, website design, branding, SEO, digital marketing, and social media management.',
  keywords:
    'Shopify, E-commerce, Website Design, Branding, SEO, Digital Marketing, Social Media',
  openGraph: {
    title: 'Seyi Growth | Shopify & E-commerce Growth Specialist',
    description:
      'I help businesses increase sales through Shopify store design, website design, branding, SEO, digital marketing, and social media management.',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-white text-gray-900`}>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
